-- phpMyAdmin SQL Dump
-- version 4.4.6.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Окт 12 2015 г., 00:03
-- Версия сервера: 5.6.26-74.0-beget-log
-- Версия PHP: 5.5.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `fb3809sd_work`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Message`
--
-- Создание: Окт 11 2015 г., 16:42
--

DROP TABLE IF EXISTS `Message`;
CREATE TABLE IF NOT EXISTS `Message` (
  `Id` int(11) NOT NULL,
  `Id_room` int(11) NOT NULL,
  `Id_author` int(11) NOT NULL,
  `Text` varchar(255) NOT NULL,
  `Private` int(11) NOT NULL,
  `Id_reader` int(11) NOT NULL,
  `Date` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Message`
--

INSERT INTO `Message` (`Id`, `Id_room`, `Id_author`, `Text`, `Private`, `Id_reader`, `Date`) VALUES
(12, 3, 5, 'ага', 0, 0, 1444581769),
(13, 3, 5, 'df', 0, 0, 1444582006),
(14, 3, 5, 'r', 0, 0, 1444582008),
(15, 3, 5, 'f', 0, 0, 1444582009),
(16, 3, 5, 'r', 0, 0, 1444582010),
(17, 3, 5, 'e', 0, 0, 1444582011),
(18, 3, 5, 'd', 0, 0, 1444582017),
(20, 3, 5, 'd', 0, 0, 1444582018),
(30, 4, 7, 'n', 0, 0, 1444585287),
(31, 4, 7, 'tcnm', 0, 0, 1444594167),
(32, 3, 6, 're', 1, 5, 1444596067);

-- --------------------------------------------------------

--
-- Структура таблицы `Room`
--
-- Создание: Окт 08 2015 г., 14:36
--

DROP TABLE IF EXISTS `Room`;
CREATE TABLE IF NOT EXISTS `Room` (
  `id` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Room`
--

INSERT INTO `Room` (`id`, `Name`) VALUES
(3, 'Room #1'),
(4, 'Спам');

-- --------------------------------------------------------

--
-- Структура таблицы `User`
--
-- Создание: Окт 08 2015 г., 15:00
--

DROP TABLE IF EXISTS `User`;
CREATE TABLE IF NOT EXISTS `User` (
  `Id` int(11) NOT NULL,
  `Login` varchar(20) NOT NULL,
  `Password_md5` varchar(36) NOT NULL,
  `Rank` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `User`
--

INSERT INTO `User` (`Id`, `Login`, `Password_md5`, `Rank`) VALUES
(5, 'Igor', '3b9984ca35f3eb410ec3573dd8277eaf', 2),
(6, 'Misha', '3b9984ca35f3eb410ec3573dd8277eaf', 2),
(7, 'Admin', '8479f48ad4a141faaf9330b12c4625f9', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `User_in_room`
--
-- Создание: Окт 08 2015 г., 14:45
--

DROP TABLE IF EXISTS `User_in_room`;
CREATE TABLE IF NOT EXISTS `User_in_room` (
  `Id` int(11) NOT NULL,
  `Id_user` int(11) NOT NULL,
  `Id_room` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `User_in_room`
--

INSERT INTO `User_in_room` (`Id`, `Id_user`, `Id_room`) VALUES
(4, 5, 3),
(5, 6, 3),
(6, 7, 3),
(7, 5, 4),
(8, 6, 4),
(9, 7, 4);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `Message`
--
ALTER TABLE `Message`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Id_room` (`Id_room`),
  ADD KEY `Id_room_2` (`Id_room`);

--
-- Индексы таблицы `Room`
--
ALTER TABLE `Room`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`Id`);

--
-- Индексы таблицы `User_in_room`
--
ALTER TABLE `User_in_room`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Id_user` (`Id_user`),
  ADD KEY `Id_room` (`Id_room`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `Message`
--
ALTER TABLE `Message`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT для таблицы `Room`
--
ALTER TABLE `Room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `User`
--
ALTER TABLE `User`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `User_in_room`
--
ALTER TABLE `User_in_room`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `Message`
--
ALTER TABLE `Message`
  ADD CONSTRAINT `Message_ibfk_1` FOREIGN KEY (`Id_room`) REFERENCES `Room` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `User_in_room`
--
ALTER TABLE `User_in_room`
  ADD CONSTRAINT `User_in_room_ibfk_1` FOREIGN KEY (`Id_user`) REFERENCES `User` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `User_in_room_ibfk_2` FOREIGN KEY (`Id_room`) REFERENCES `Room` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
